# netwhat42

**Questions : 37**.<br/><br/>

Pour lancer le script :<br/>
./netwhat42 [nombre]<br/><br/>
Utilisez les flèches directionnelles et la touche entrée pour repondre aux questions.<br/>
Le QCM est valide seulement si toutes les questions sont justes.

---------------------------------------------------------------------------------

To launch the script: <br/>
./netwhat42 [number]<br/><br/>
Use the directional arrows and the enter key to answer the questions. <br/>
The MCQ is valid only if all questions are correct.

![Screenshot question](https://i.imgur.com/y2WvYOw.png)
